Tessel-Greenhouse
=================

An API for monitoring and managing a greenhouse over the web with a Tessel.io

Part of the Hack Reactor Tessel.io one-day hackathon

Planned features:

 - Cooling fan based on temp/humidity
 - additional planned features...