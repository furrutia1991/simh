tessel
======

A demo app for using openshift, nodejs, to create a web app to control a tessel
